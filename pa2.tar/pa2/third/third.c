#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	unsigned short Value = atoi(argv[1]);
	int x;
	int True = 1;
	for(x = 0; x<8; x++){
		if((Value>>(15-x))%2 != (Value>>x)%2)
			True = 0;
	}
	
	if(True == 0)
		printf("Not-Palindrome");
	else
		printf("Is-Palindrome");
}
