#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	unsigned short Value = atoi(argv[1]);
	int x;
	int even = 0;
	int ones = 0;
	int onesT = 0;
	for(x = 0; x<16; x++){
		if((Value>>x)%2==1){
			even++;
			ones++;
		}
		else{
			onesT = onesT + (ones/2);
			ones = 0;
		}	
	}
	if(even%2 == 0)
		printf("Even-Parity\t");
	else
		printf("Odd-Parity\t");

	printf("%i", onesT);
}
