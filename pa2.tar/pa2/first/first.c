#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char* argv[]){
	FILE *fp;
	fp = fopen(argv[1], "r");
	unsigned short Value;
	fscanf(fp, "%hu", &Value);
	char action[5];
	int first;
	int second;
	while(!feof(fp)){
		fscanf(fp, "%s", action);
		if(feof(fp))
			break;
		fscanf(fp, "%d", &first);
		fscanf(fp, "%d", &second);
		
		int get = strcmp(action, "get");
		int comp = strcmp(action, "comp");
		int set = strcmp(action, "set");
		if(get == 0){
			if((Value >> first) %2==0)
				printf("%d\n", 0);
			else
				printf("%d\n", 1);
		}
		else if(comp == 0){
			Value = Value ^ ((unsigned short)pow(2, first));
			printf("%hu\n", Value);
                }
		else if(set == 0){
			if((Value >> first)%2!=second)
                                Value = Value ^ ((unsigned short)pow(2, first));
			printf("%hu\n", Value);
                }
	}
	fclose(fp);
}
